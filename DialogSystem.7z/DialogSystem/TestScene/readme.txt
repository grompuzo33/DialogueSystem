Для теста диалога нажмите пробел. 


Если у вас ошибка:
InvalidOperationException: You are trying to read Input using the UnityEngine.Input class, but you have switched active Input handling to Input System package in Player Settings.

То сделайте это:
Открой Edit → Project Settings → Player.

В разделе Other Settings → Active Input Handling выбери Both (вместо Input System Package (New)).



Press the Space key to test the dialogue.

If you get the error:
InvalidOperationException: You are trying to read Input using the UnityEngine.Input class, but you have switched active Input handling to Input System package in Player Settings.

Do the following:
Open Edit → Project Settings → Player.

In the Other Settings → Active Input Handling section, select Both (instead of Input System Package (New)).