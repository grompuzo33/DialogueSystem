using UnityEngine;

public class DialogueEventHandler : MonoBehaviour
{
    void Start()
    {
        
        DialogueSystem.OnDialogueEnterEvent += OnDialogueEnter;
        DialogueSystem.OnDialogueExitEvent += OnDialogueExit;
    }

    void OnDestroy()
    {
        
        DialogueSystem.OnDialogueEnterEvent -= OnDialogueEnter;
        DialogueSystem.OnDialogueExitEvent -= OnDialogueExit;
    }

    private void OnDialogueEnter(string eventName)
    {


        switch (eventName)
        {
            case "DebugEnter":
                DialogueDebugEnter();
                break;
        }
    }

    private void OnDialogueExit(string eventName)
    {
        switch (eventName)
        {
            case "DebugExit":
                DialogueDebugExit();
                break;
        }

    }

    
    void DialogueDebugEnter()
    {
        Debug.Log("DialogueDebugEnter");
    }
    void DialogueDebugExit()
    {
        Debug.Log("DialogueDebugExit");
    }
}