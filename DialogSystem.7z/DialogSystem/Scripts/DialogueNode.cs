using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class DialogueNode
{
    public string ID;
    public string Speaker;
    [TextArea(3, 5)] public string Text;
    public List<DialogueOption> Options;
    public Vector2 EditorPosition;
    public Vector2 NodeSize = new Vector2(300f, 200f);
    public string NextNodeID; // Field for sequential connection
    public string OnEnterEvent; // Event triggered when entering the node
    public string OnExitEvent; // Event triggered when exiting the node

    /// <summary>
    /// Initializes a new dialogue node with default values
    /// </summary>
    public DialogueNode()
    {
        ID = Guid.NewGuid().ToString();
        Options = new List<DialogueOption>();
        NextNodeID = string.Empty;
        OnEnterEvent = string.Empty;
        OnExitEvent = string.Empty;
    }
}
