using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Dialogue", menuName = "Dialogue System/Dialogue")]
public class Dialogue : ScriptableObject
{
    public List<DialogueNode> Nodes = new List<DialogueNode>();
    public string StartNodeID;

    /// <summary>
    /// Finds a dialogue node by its unique identifier
    /// </summary>
    /// <param name="id">The ID of the node to find</param>
    /// <returns>The found node or null if not found</returns>
    public DialogueNode GetNodeByID(string id)
    {
        return Nodes.Find(node => node.ID == id);
    }

    /// <summary>
    /// Retrieves the starting node for this dialogue
    /// </summary>
    /// <returns>The start node or first node if no start specified</returns>
    public DialogueNode GetStartNode()
    {
        // Use specific StartNodeID if provided
        if (!string.IsNullOrEmpty(StartNodeID))
        {
            var startNode = GetNodeByID(StartNodeID);
            if (startNode != null) return startNode;
        }

        // Fallback to first node or null if empty
        return Nodes.Count > 0 ? Nodes[0] : null;
    }
}
