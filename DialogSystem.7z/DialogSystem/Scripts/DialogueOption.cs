using System;

[Serializable]
public class DialogueOption
{
    public string Text;
    public string TargetNodeID;
}
