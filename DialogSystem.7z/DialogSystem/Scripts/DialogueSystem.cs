using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;
using System;

public class DialogueSystem : MonoBehaviour
{
    [SerializeField] private GameObject dialoguePanel;
    [SerializeField] private TextMeshProUGUI speakerText;
    [SerializeField] private TextMeshProUGUI dialogueText;
    [SerializeField] private Transform optionsContainer;
    [SerializeField] private Button optionButtonPrefab;

    // Events for external method invocation
    public static event Action<string> OnDialogueEvent;
    public static event Action<string> OnDialogueEnterEvent;
    public static event Action<string> OnDialogueExitEvent;

    private Dialogue currentDialogue;
    private DialogueNode currentNode;
    //private DialogueNode previousNode;
    private bool isDialogueActive = false;
    private bool ignoreFirstClick = true;
    private float dialogueStartTime;

    /// <summary>
    /// Initializes the dialogue system UI components
    /// </summary>
    private void Awake()
    {
        if (dialoguePanel != null)
            dialoguePanel.SetActive(false);
    }

    /// <summary>
    /// Starts a dialogue sequence with the provided dialogue asset
    /// </summary>
    /// <param name="dialogue">The dialogue asset to play</param>
    public void StartDialogue(Dialogue dialogue)
    {
        if (dialogue == null) return;

        currentDialogue = dialogue;
        currentNode = currentDialogue.GetStartNode();

        if (currentNode == null)
        {
            Debug.LogError("Dialogue has no start node!");
            return;
        }

        isDialogueActive = true;
        dialoguePanel.SetActive(true);
        ignoreFirstClick = true;
        dialogueStartTime = Time.time;

        TriggerEnterEvent(currentNode);
        DisplayNode(currentNode);
    }

    /// <summary>
    /// Displays the content of a specific dialogue node
    /// </summary>
    /// <param name="node">The node to display</param>
    private void DisplayNode(DialogueNode node)
    {
        if (node == null)
        {
            EndDialogue();
            return;
        }

        if (currentNode != null && currentNode != node)
        {
            TriggerExitEvent(currentNode);
        }

        currentNode = node;
        speakerText.text = node.Speaker;
        dialogueText.text = node.Text;

        ClearOptions();

        TriggerEnterEvent(node);

        if (!string.IsNullOrEmpty(node.NextNodeID) || node.Options == null || node.Options.Count == 0)
        {
            return;
        }

        CreateOptionButtons(node);
    }

    /// <summary>
    /// Clears all existing option buttons from the container
    /// </summary>
    private void ClearOptions()
    {
        foreach (Transform child in optionsContainer)
            Destroy(child.gameObject);
    }

    /// <summary>
    /// Creates option buttons for the current node's choices
    /// </summary>
    /// <param name="node">The node containing the options</param>
    private void CreateOptionButtons(DialogueNode node)
    {
        foreach (DialogueOption option in node.Options)
        {
            Button optionButton = Instantiate(optionButtonPrefab, optionsContainer);
            optionButton.GetComponentInChildren<TextMeshProUGUI>().text = option.Text;

            if (!string.IsNullOrEmpty(option.TargetNodeID))
            {
                optionButton.onClick.AddListener(() => {
                    DialogueNode nextNode = currentDialogue.GetNodeByID(option.TargetNodeID);
                    DisplayNode(nextNode);
                });
            }
            else
            {
                optionButton.onClick.AddListener(EndDialogue);
            }
        }
    }

    /// <summary>
    /// Triggers the enter event for a dialogue node
    /// </summary>
    /// <param name="node">The node triggering the event</param>
    private void TriggerEnterEvent(DialogueNode node)
    {
        if (!string.IsNullOrEmpty(node.OnEnterEvent))
        {
            OnDialogueEnterEvent?.Invoke(node.OnEnterEvent);
            OnDialogueEvent?.Invoke(node.OnEnterEvent);
            Debug.Log($"Dialogue Enter Event: {node.OnEnterEvent}");
        }
    }

    /// <summary>
    /// Triggers the exit event for a dialogue node
    /// </summary>
    /// <param name="node">The node triggering the event</param>
    private void TriggerExitEvent(DialogueNode node)
    {
        if (!string.IsNullOrEmpty(node.OnExitEvent))
        {
            OnDialogueExitEvent?.Invoke(node.OnExitEvent);
            OnDialogueEvent?.Invoke(node.OnExitEvent);
            Debug.Log($"Dialogue Exit Event: {node.OnExitEvent}");
        }
    }

    /// <summary>
    /// Ends the current dialogue sequence and cleans up
    /// </summary>
    private void EndDialogue()
    {
        if (currentNode != null)
        {
            TriggerExitEvent(currentNode);
        }

        isDialogueActive = false;
        dialoguePanel.SetActive(false);
        currentDialogue = null;
        currentNode = null;
        //previousNode = null;
    }

    /// <summary>
    /// Checks if a dialogue is currently active
    /// </summary>
    /// <returns>True if dialogue is active</returns>
    public bool IsDialogueActive()
    {
        return isDialogueActive;
    }

    /// <summary>
    /// Handles input processing for dialogue advancement
    /// </summary>
    private void Update()
    {
        if (isDialogueActive && Input.GetMouseButtonDown(0))
        {
            if (!isDialogueActive) return;

            if (ignoreFirstClick && Time.time - dialogueStartTime > 0.2f)
            {
                ignoreFirstClick = false;
            }

            if (Input.GetMouseButtonDown(0) && !ignoreFirstClick)
            {
                HandleLeftClickAdvancement();
            }
        }
    }

    /// <summary>
    /// Handles dialogue advancement on left mouse button click
    /// </summary>
    private void HandleLeftClickAdvancement()
    {
        if (!string.IsNullOrEmpty(currentNode.NextNodeID))
        {
            DialogueNode nextNode = currentDialogue.GetNodeByID(currentNode.NextNodeID);
            DisplayNode(nextNode);
        }
        else if (currentNode.Options == null || currentNode.Options.Count == 0)
        {
            EndDialogue();
        }
    }

    /// <summary>
    /// Manually triggers a dialogue event by name
    /// </summary>
    /// <param name="eventName">The name of the event to trigger</param>
    public static void TriggerEvent(string eventName)
    {
        OnDialogueEvent?.Invoke(eventName);
    }
}
