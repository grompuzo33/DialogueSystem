
using System.Collections.Generic;
using UnityEngine;

public class CharacterInteraction : MonoBehaviour
{
    // Example interaction component for testing dialogue system

    [SerializeField] public DialogueSystem DialogueSystem;
    [SerializeField] public Dialogue dialogue;

    /// <summary>
    /// �riggering dialogue with Space key
    /// </summary>
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            DialogueSystem.StartDialogue(dialogue);
        }
    }
}
