﻿#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;


public class DialogueEditor : EditorWindow
{
    private Dialogue currentDialogue;
    private Vector2 scrollPosition;
    private DialogueNode connectingFromNode;
    private DialogueNode resizingNode;
    private bool isMakingConnection = false;
    private bool isResizing = false;
    //private ResizeDirection resizeDirection = ResizeDirection.None;
    private Vector2 resizeStartPosition;
    private Vector2 resizeStartSize;

    private bool isPanning = false;
    private Vector2 panStartMousePosition;
    private Vector2 panStartScrollPosition;

    private GUIStyle nodeStyle;
    private GUIStyle selectedNodeStyle;
    private GUIStyle resizeStyle;
    private GUIStyle sequentialConnectionStyle;

    private const float MIN_NODE_WIDTH = 270f;
    private const float MIN_NODE_HEIGHT = 300f;
    private const float RESIZE_HANDLE_SIZE = 15f;
    private const float OPTION_HEIGHT = 25f;

    private string defaultSpeakerName = "NPC";
    private bool showSettings = false;

    private enum ResizeDirection
    {
        None,
        Right,
        Bottom,
        BottomRight
    }

    [MenuItem("Window/Dialogue Editor")]
    public static void ShowWindow()
    {
        GetWindow<DialogueEditor>("Dialogue Editor");
    }

    private void OnEnable()
    {
        SetupStyles();
        wantsMouseMove = true;
        defaultSpeakerName = EditorPrefs.GetString("DialogueEditor_DefaultSpeakerName", "NPC");
    }

    private void OnDisable()
    {
        EditorPrefs.SetString("DialogueEditor_DefaultSpeakerName", defaultSpeakerName);
    }

    /// <summary>
    /// Initializes GUI styles for nodes and UI elements
    /// </summary>
    private void SetupStyles()
    {
        nodeStyle = new GUIStyle();
        nodeStyle.normal.background = MakeTex(600, 400, new Color(0.3f, 0.3f, 0.5f));
        nodeStyle.border = new RectOffset(12, 12, 12, 12);
        nodeStyle.padding = new RectOffset(10, 10, 10, 10);
        nodeStyle.normal.textColor = Color.white;

        selectedNodeStyle = new GUIStyle();
        selectedNodeStyle.normal.background = MakeTex(600, 400, new Color(0.4f, 0.4f, 0.6f));
        selectedNodeStyle.border = new RectOffset(12, 12, 12, 12);
        selectedNodeStyle.padding = new RectOffset(10, 10, 10, 10);
        selectedNodeStyle.normal.textColor = Color.white;

        resizeStyle = new GUIStyle();
        resizeStyle.normal.background = MakeTex(20, 20, new Color(0.8f, 0.8f, 0.8f, 0.8f));

        sequentialConnectionStyle = new GUIStyle();
        sequentialConnectionStyle.normal.textColor = Color.blue;
        sequentialConnectionStyle.fontStyle = FontStyle.Bold;
    }

    /// <summary>
    /// Creates a solid color texture for GUI backgrounds
    /// </summary>
    private Texture2D MakeTex(int width, int height, Color col)
    {
        Color[] pix = new Color[width * height];
        for (int i = 0; i < pix.Length; ++i)
            pix[i] = col;
        Texture2D result = new Texture2D(width, height);
        result.SetPixels(pix);
        result.Apply();
        return result;
    }

    private void OnGUI()
    {
        if (currentDialogue == null)
        {
            DrawSelectionPanel();
            return;
        }

        DrawToolbar();
        DrawBackgroundGrid();

        // Correct rendering order
        DrawConnections();

        BeginWindows();
        DrawNodes();
        EndWindows();

        ProcessEvents(Event.current);

        if (showSettings)
        {
            DrawSettingsPanel();
        }
    }

    /// <summary>
    /// Converts world position to screen position for rendering
    /// </summary>
    private Vector2 WorldToScreenPosition(Vector2 worldPos)
    {
        return worldPos + scrollPosition;
    }

    /// <summary>
    /// Converts screen position to world position for node placement
    /// </summary>
    private Vector2 ScreenToWorldPosition(Vector2 screenPos)
    {
        return screenPos - scrollPosition;
    }

    /// <summary>
    /// Draws all connections between dialogue nodes
    /// </summary>
    private void DrawConnections()
    {
        if (currentDialogue.Nodes == null) return;

        foreach (var node in currentDialogue.Nodes)
        {
            // Standard option connections
            if (node.Options != null)
            {
                foreach (var option in node.Options)
                {
                    if (!string.IsNullOrEmpty(option.TargetNodeID))
                    {
                        var targetNode = currentDialogue.GetNodeByID(option.TargetNodeID);
                        if (targetNode != null)
                        {
                            DrawNodeConnection(node, targetNode, Color.green);
                        }
                    }
                }
            }

            // Sequential connections
            if (!string.IsNullOrEmpty(node.NextNodeID))
            {
                var targetNode = currentDialogue.GetNodeByID(node.NextNodeID);
                if (targetNode != null)
                {
                    DrawNodeConnection(node, targetNode, Color.blue);
                }
            }
        }

        // Temporary connection during creation
        if (isMakingConnection && connectingFromNode != null)
        {
            Vector2 startPos = connectingFromNode.EditorPosition +
                              new Vector2(connectingFromNode.NodeSize.x, connectingFromNode.NodeSize.y / 2);
            Vector2 screenStart = WorldToScreenPosition(startPos);

            Handles.color = Color.yellow;
            Handles.DrawLine(screenStart, Event.current.mousePosition);
            Handles.DrawSolidDisc(Event.current.mousePosition, Vector3.forward, 5f);
        }
    }

    /// <summary>
    /// Draws a bezier connection between two nodes
    /// </summary>
    private void DrawNodeConnection(DialogueNode fromNode, DialogueNode toNode, Color color)
    {
        Vector2 fromScreenPos = WorldToScreenPosition(fromNode.EditorPosition);
        Vector2 toScreenPos = WorldToScreenPosition(toNode.EditorPosition);

        Vector2 startPos = fromScreenPos + new Vector2(fromNode.NodeSize.x, fromNode.NodeSize.y / 2);
        Vector2 endPos = toScreenPos + new Vector2(0, toNode.NodeSize.y / 2);

        Handles.color = color;
        Handles.DrawBezier(startPos, endPos,
                          startPos + Vector2.right * 50f,
                          endPos + Vector2.left * 50f,
                          color, null, 3f);

        Handles.DrawSolidDisc(endPos, Vector3.forward, 5f);
    }

    /// <summary>
    /// Draws background grid for visual reference
    /// </summary>
    private void DrawBackgroundGrid()
    {
        Handles.BeginGUI();

        float gridSize = 20f;
        float gridOpacity = 0.1f;

        Handles.color = new Color(0.5f, 0.5f, 0.5f, gridOpacity);

        // Draw vertical lines
        for (float x = scrollPosition.x % gridSize; x < position.width; x += gridSize)
        {
            Handles.DrawLine(new Vector3(x, 0, 0), new Vector3(x, position.height, 0));
        }

        // Draw horizontal lines
        for (float y = scrollPosition.y % gridSize; y < position.height; y += gridSize)
        {
            Handles.DrawLine(new Vector3(0, y, 0), new Vector3(position.width, y, 0));
        }

        Handles.EndGUI();
    }

    /// <summary>
    /// Draws the settings panel for editor configuration
    /// </summary>
    private void DrawSettingsPanel()
    {
        GUILayout.BeginArea(new Rect(position.width - 250, 50, 240, 100), GUI.skin.box);
        GUILayout.Label("Editor Settings", EditorStyles.boldLabel);

        EditorGUI.BeginChangeCheck();
        defaultSpeakerName = EditorGUILayout.TextField("Default Name", defaultSpeakerName);
        if (EditorGUI.EndChangeCheck())
        {
            EditorPrefs.SetString("DialogueEditor_DefaultSpeakerName", defaultSpeakerName);
        }

        if (GUILayout.Button("Close"))
        {
            showSettings = false;
        }

        GUILayout.EndArea();
    }

    /// <summary>
    /// Draws the initial panel for selecting or creating dialogues
    /// </summary>
    private void DrawSelectionPanel()
    {
        EditorGUILayout.HelpBox("Select a Dialogue asset or create a new one.", MessageType.Info);

        if (GUILayout.Button("Create New Dialogue"))
        {
            CreateNewDialogue();
        }

        currentDialogue = (Dialogue)EditorGUILayout.ObjectField("Dialogue Asset", currentDialogue, typeof(Dialogue), false);
    }

    /// <summary>
    /// Draws the top toolbar with action buttons
    /// </summary>
    private void DrawToolbar()
    {
        EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);

        if (GUILayout.Button("New Node", EditorStyles.toolbarButton))
        {
            AddNewNode();
        }

        if (GUILayout.Button("Save", EditorStyles.toolbarButton))
        {
            SaveDialogue();
        }

        GUILayout.FlexibleSpace();

        if (GUILayout.Button("Settings", EditorStyles.toolbarButton))
        {
            showSettings = !showSettings;
        }

        if (GUILayout.Button("Center View", EditorStyles.toolbarButton))
        {
            CenterView();
        }

        if (GUILayout.Button("Reset Positions", EditorStyles.toolbarButton))
        {
            foreach (var node in currentDialogue.Nodes)
            {
                node.EditorPosition = Vector2.zero;
            }
            EditorUtility.SetDirty(currentDialogue);
            Repaint();
        }

        EditorGUILayout.EndHorizontal();
    }

    /// <summary>
    /// Draws the content of a dialogue node window
    /// </summary>
    private void DrawNodeWindow(int id)
    {
        if (currentDialogue.Nodes == null || id >= currentDialogue.Nodes.Count) return;

        DialogueNode node = currentDialogue.Nodes[id];

        EditorGUI.BeginChangeCheck();

        GUILayout.BeginVertical(GUILayout.ExpandHeight(true));
        GUILayout.Space(10);

        // Button to set as start node
        EditorGUILayout.BeginHorizontal();
        bool isStartNode = currentDialogue.StartNodeID == node.ID;
        if (isStartNode)
        {
            EditorGUILayout.LabelField("★ START NODE", EditorStyles.boldLabel);
        }
        else if (GUILayout.Button("Set as Start", EditorStyles.miniButton))
        {
            currentDialogue.StartNodeID = node.ID;
            EditorUtility.SetDirty(currentDialogue);
        }

        // Node deletion button
        if (GUILayout.Button("X", EditorStyles.miniButton, GUILayout.Width(20)))
        {
            DeleteNode(node);
            GUIUtility.ExitGUI(); // Properly exit GUI
            return;
        }

        EditorGUILayout.EndHorizontal();

        // Speaker field
        EditorGUILayout.LabelField("Speaker:", EditorStyles.boldLabel);
        node.Speaker = EditorGUILayout.TextField(node.Speaker);

        EditorGUILayout.Space(5);

        // Text area - MOVED UP!
        EditorGUILayout.LabelField("Dialogue Text:", EditorStyles.boldLabel);
        GUIStyle textAreaStyle = new GUIStyle(EditorStyles.textArea);
        textAreaStyle.wordWrap = true;

        float textHeight = textAreaStyle.CalcHeight(new GUIContent(node.Text), MIN_NODE_WIDTH - 30);
        textHeight = Mathf.Max(60, textHeight);
        node.Text = EditorGUILayout.TextArea(node.Text, textAreaStyle, GUILayout.Height(textHeight));

        EditorGUILayout.Space(5);

        // Node events - ADDED HERE
        EditorGUILayout.LabelField("Events:", EditorStyles.boldLabel);
        EditorGUILayout.BeginVertical(EditorStyles.helpBox);

        EditorGUILayout.LabelField("On Enter Event:", EditorStyles.miniBoldLabel);
        node.OnEnterEvent = EditorGUILayout.TextField(node.OnEnterEvent);

        EditorGUILayout.LabelField("On Exit Event:", EditorStyles.miniBoldLabel);
        node.OnExitEvent = EditorGUILayout.TextField(node.OnExitEvent);

        EditorGUILayout.EndVertical();

        EditorGUILayout.Space(5);

        // Sequential connection (Next Node)
        EditorGUILayout.LabelField("Sequential Connection:", EditorStyles.boldLabel);
        EditorGUILayout.BeginHorizontal();

        if (!string.IsNullOrEmpty(node.NextNodeID))
        {
            var nextNode = currentDialogue.GetNodeByID(node.NextNodeID);
            EditorGUILayout.LabelField(nextNode != null ? $"→ {nextNode.Speaker}" : "→ Invalid",
                EditorStyles.miniLabel, GUILayout.Width(100));
        }
        else
        {
            EditorGUILayout.LabelField("→ None", EditorStyles.miniLabel, GUILayout.Width(100));
        }

        if (GUILayout.Button("Set Next", EditorStyles.miniButton, GUILayout.Width(60)))
        {
            connectingFromNode = node;
            isMakingConnection = true;
        }

        if (!string.IsNullOrEmpty(node.NextNodeID) &&
            GUILayout.Button("Clear", EditorStyles.miniButton, GUILayout.Width(50)))
        {
            node.NextNodeID = string.Empty;
        }

        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space(5);

        // Options section
        EditorGUILayout.LabelField("Options (Choice):", EditorStyles.boldLabel);

        if (node.Options == null) node.Options = new List<DialogueOption>();

        for (int i = 0; i < node.Options.Count; i++)
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.LabelField("Text:", GUILayout.Width(40));
            node.Options[i].Text = EditorGUILayout.TextField(node.Options[i].Text, GUILayout.MinWidth(100));

            if (!string.IsNullOrEmpty(node.Options[i].TargetNodeID))
            {
                var targetNode = currentDialogue.GetNodeByID(node.Options[i].TargetNodeID);
                EditorGUILayout.LabelField(targetNode != null ? $"→ {targetNode.Speaker}" : "→ Invalid",
                    EditorStyles.miniLabel, GUILayout.Width(80));
            }
            else
            {
                EditorGUILayout.LabelField("→ End", EditorStyles.miniLabel, GUILayout.Width(80));
            }

            if (GUILayout.Button("X", EditorStyles.miniButton, GUILayout.Width(20)))
            {
                node.Options.RemoveAt(i);
                i--;
            }

            EditorGUILayout.EndHorizontal();
            EditorGUILayout.EndVertical();
        }

        if (GUILayout.Button("Add Option", EditorStyles.miniButton))
        {
            node.Options.Add(new DialogueOption { Text = "New Option" });
        }

        EditorGUILayout.Space(10);

        // Connection buttons
        EditorGUILayout.BeginHorizontal();

        if (GUILayout.Button("Connect From", EditorStyles.miniButtonLeft))
        {
            connectingFromNode = node;
            isMakingConnection = true;
        }

        if (GUILayout.Button("Connect To", EditorStyles.miniButtonMid))
        {
            if (isMakingConnection && connectingFromNode != null && connectingFromNode != node)
            {
                if (Event.current.shift)
                {
                    connectingFromNode.NextNodeID = node.ID;
                }
                else
                {
                    CreateOptionConnection(connectingFromNode, node);
                }
                isMakingConnection = false;
                connectingFromNode = null;
            }
        }

        EditorGUILayout.EndHorizontal();

        GUILayout.EndVertical();

        // Automatic height adjustment based on content
        if (Event.current.type == EventType.Repaint)
        {
            Rect lastRect = GUILayoutUtility.GetLastRect();
            float contentHeight = lastRect.y + lastRect.height + 10;

            float minHeightWithOptions = MIN_NODE_HEIGHT + (node.Options != null ? node.Options.Count * OPTION_HEIGHT : 0);
            float newHeight = Mathf.Max(minHeightWithOptions, contentHeight);

            node.NodeSize = new Vector2(
                Mathf.Max(MIN_NODE_WIDTH, node.NodeSize.x),
                newHeight
            );
        }

        if (EditorGUI.EndChangeCheck())
        {
            EditorUtility.SetDirty(currentDialogue);
        }

        // Draw resize handle
        Rect resizeHandle = new Rect(
            GUILayoutUtility.GetLastRect().x + GUILayoutUtility.GetLastRect().width - RESIZE_HANDLE_SIZE,
            GUILayoutUtility.GetLastRect().y + GUILayoutUtility.GetLastRect().height - RESIZE_HANDLE_SIZE,
            RESIZE_HANDLE_SIZE,
            RESIZE_HANDLE_SIZE
        );
        GUI.Box(resizeHandle, "", resizeStyle);

        GUI.DragWindow();
    }

    /// <summary>
    /// Draws all dialogue nodes as draggable windows
    /// </summary>
    private void DrawNodes()
    {
        if (currentDialogue.Nodes == null) return;

        for (int i = 0; i < currentDialogue.Nodes.Count; i++)
        {
            var node = currentDialogue.Nodes[i];

            Vector2 screenPos = WorldToScreenPosition(node.EditorPosition);
            Rect screenRect = new Rect(screenPos, node.NodeSize);

            GUIStyle style = nodeStyle;
            bool isStartNode = currentDialogue.StartNodeID == node.ID;
            string title = isStartNode ? $"★ {node.Speaker}" : node.Speaker;

            screenRect = GUI.Window(i, screenRect, DrawNodeWindow, title, style);

            node.EditorPosition = ScreenToWorldPosition(screenRect.position);
            node.NodeSize = screenRect.size;
        }
    }

    /// <summary>
    /// Processes mouse and keyboard events for the editor
    /// </summary>
    private void ProcessEvents(Event currentEvent)
    {
        Vector2 mouseWorldPos = ScreenToWorldPosition(currentEvent.mousePosition);

        // Handle resize
        if (currentEvent.type == EventType.MouseDown && currentEvent.button == 0)
        {
            HandleResizeStart(mouseWorldPos, currentEvent);
        }
        else if (currentEvent.type == EventType.MouseDrag && currentEvent.button == 0 && isResizing)
        {
            HandleResizeDrag(mouseWorldPos, currentEvent);
        }
        else if (currentEvent.type == EventType.MouseUp && currentEvent.button == 0)
        {
            HandleResizeEnd();

            if (isMakingConnection && connectingFromNode != null)
            {
                DialogueNode targetNode = GetNodeAtPosition(mouseWorldPos);
                if (targetNode != null && connectingFromNode != targetNode)
                {
                    if (Event.current.shift)
                    {
                        connectingFromNode.NextNodeID = targetNode.ID;
                    }
                    else
                    {
                        CreateOptionConnection(connectingFromNode, targetNode);
                    }
                }
                isMakingConnection = false;
                connectingFromNode = null;
                Repaint();
            }
        }

        // Handle middle mouse button panning
        switch (currentEvent.type)
        {
            case EventType.MouseDown:
                if (currentEvent.button == 1) // Right mouse button
                {
                    if (currentEvent.shift) // Shift + RMB - create new node
                    {
                        AddNewNodeAtPosition(mouseWorldPos);
                        currentEvent.Use();
                    }
                    else if (currentEvent.control) // Ctrl + RMB - delete node under cursor
                    {
                        DeleteNodeAtPosition(mouseWorldPos);
                        currentEvent.Use();
                    }
                }
                if (currentEvent.button == 2) // Middle mouse button
                {
                    isPanning = true;
                    panStartMousePosition = currentEvent.mousePosition;
                    panStartScrollPosition = scrollPosition;
                    currentEvent.Use();
                }
                break;

            case EventType.MouseDrag:
                if (isPanning && currentEvent.button == 2)
                {
                    // INVERTED movement: move mouse right - scroll right
                    Vector2 delta = currentEvent.mousePosition - panStartMousePosition;
                    scrollPosition = panStartScrollPosition - delta;
                    currentEvent.Use();
                    Repaint();
                }
                break;

            case EventType.MouseUp:
                if (currentEvent.button == 2)
                {
                    isPanning = false;
                    currentEvent.Use();
                }
                break;

            case EventType.KeyDown:
                if (currentEvent.keyCode == KeyCode.Delete)
                {
                    DialogueNode nodeToDelete = GetNodeAtPosition(mouseWorldPos);
                    if (nodeToDelete != null)
                    {
                        DeleteNode(nodeToDelete);
                    }
                }
                break;
        }
    }

    /// <summary>
    /// Adds a new node at the specified world position
    /// </summary>
    private void AddNewNodeAtPosition(Vector2 worldPosition)
    {
        if (currentDialogue.Nodes == null) currentDialogue.Nodes = new List<DialogueNode>();

        DialogueNode newNode = new DialogueNode
        {
            Speaker = defaultSpeakerName,
            Text = "Enter dialogue text here...",
            EditorPosition = worldPosition,
            NodeSize = new Vector2(MIN_NODE_WIDTH, MIN_NODE_HEIGHT + 100),
            NextNodeID = string.Empty
        };

        currentDialogue.Nodes.Add(newNode);

        if (currentDialogue.Nodes.Count == 1)
            currentDialogue.StartNodeID = newNode.ID;

        EditorUtility.SetDirty(currentDialogue);
        Repaint();
    }

    /// <summary>
    /// Deletes the node at the specified world position
    /// </summary>
    private void DeleteNodeAtPosition(Vector2 worldPosition)
    {
        DialogueNode nodeToDelete = GetNodeAtPosition(worldPosition);
        if (nodeToDelete != null)
        {
            DeleteNode(nodeToDelete);
        }
    }

    /// <summary>
    /// Deletes a node and removes all references to it
    /// </summary>
    private void DeleteNode(DialogueNode nodeToDelete)
    {
        if (currentDialogue.Nodes == null || nodeToDelete == null) return;

        // Remove all references to this node from other nodes
        foreach (var node in currentDialogue.Nodes)
        {
            // Remove sequential connections
            if (node.NextNodeID == nodeToDelete.ID)
            {
                node.NextNodeID = string.Empty;
            }

            // Remove option connections
            if (node.Options != null)
            {
                for (int i = node.Options.Count - 1; i >= 0; i--)
                {
                    if (node.Options[i].TargetNodeID == nodeToDelete.ID)
                    {
                        node.Options.RemoveAt(i);
                    }
                }
            }
        }

        // If this is the start node, reset the start node
        if (currentDialogue.StartNodeID == nodeToDelete.ID)
        {
            currentDialogue.StartNodeID = currentDialogue.Nodes.Count > 1 ?
                currentDialogue.Nodes.Find(n => n.ID != nodeToDelete.ID)?.ID : string.Empty;
        }

        // Remove the node itself
        currentDialogue.Nodes.Remove(nodeToDelete);

        EditorUtility.SetDirty(currentDialogue);
        Repaint();
    }

    /// <summary>
    /// Gets the node at the specified world position
    /// </summary>
    private DialogueNode GetNodeAtPosition(Vector2 position)
    {
        if (currentDialogue.Nodes == null) return null;

        foreach (var node in currentDialogue.Nodes)
        {
            Vector2 screenPos = WorldToScreenPosition(node.EditorPosition);
            Rect screenRect = new Rect(screenPos, node.NodeSize);

            if (screenRect.Contains(Event.current.mousePosition))
            {
                return node;
            }
        }
        return null;
    }

    /// <summary>
    /// Handles the start of node resizing
    /// </summary>
    private void HandleResizeStart(Vector2 mousePos, Event currentEvent)
    {
        if (currentDialogue.Nodes == null) return;

        foreach (var node in currentDialogue.Nodes)
        {
            Rect nodeRect = new Rect(node.EditorPosition, node.NodeSize);

            Rect resizeHandle = new Rect(
                nodeRect.x + nodeRect.width - RESIZE_HANDLE_SIZE,
                nodeRect.y + nodeRect.height - RESIZE_HANDLE_SIZE,
                RESIZE_HANDLE_SIZE,
                RESIZE_HANDLE_SIZE
            );

            if (resizeHandle.Contains(mousePos))
            {
                isResizing = true;
                resizingNode = node;
                //resizeDirection = ResizeDirection.BottomRight;
                resizeStartPosition = mousePos;
                resizeStartSize = node.NodeSize;
                currentEvent.Use();
                return;
            }
        }
    }

    /// <summary>
    /// Handles node resizing during mouse drag
    /// </summary>
    private void HandleResizeDrag(Vector2 mousePos, Event currentEvent)
    {
        if (isResizing && resizingNode != null)
        {
            Vector2 delta = mousePos - resizeStartPosition;

            resizingNode.NodeSize = new Vector2(
                Mathf.Max(MIN_NODE_WIDTH, resizeStartSize.x + delta.x),
                Mathf.Max(MIN_NODE_HEIGHT, resizeStartSize.y + delta.y)
            );

            currentEvent.Use();
            Repaint();
        }
    }

    /// <summary>
    /// Handles the end of node resizing
    /// </summary>
    private void HandleResizeEnd()
    {
        isResizing = false;
        resizingNode = null;
        //resizeDirection = ResizeDirection.None;
    }

    /// <summary>
    /// Creates an option connection between two nodes
    /// </summary>
    private void CreateOptionConnection(DialogueNode fromNode, DialogueNode toNode)
    {
        if (fromNode.Options == null) fromNode.Options = new List<DialogueOption>();

        DialogueOption option = fromNode.Options.Find(o => o.TargetNodeID == toNode.ID);
        if (option == null)
        {
            option = new DialogueOption
            {
                Text = $"To: {toNode.Speaker}",
                TargetNodeID = toNode.ID
            };
            fromNode.Options.Add(option);
        }
        else
        {
            option.TargetNodeID = toNode.ID;
        }

        EditorUtility.SetDirty(currentDialogue);
        Repaint();
    }

    /// <summary>
    /// Adds a new node at default position
    /// </summary>
    private void AddNewNode()
    {
        AddNewNodeAtPosition(new Vector2(100, 100));
    }

    /// <summary>
    /// Saves the current dialogue asset
    /// </summary>
    private void SaveDialogue()
    {
        EditorUtility.SetDirty(currentDialogue);
        AssetDatabase.SaveAssets();
        Debug.Log("Dialogue saved successfully!");
    }

    /// <summary>
    /// Centers the view on all nodes
    /// </summary>
    private void CenterView()
    {
        if (currentDialogue.Nodes == null || currentDialogue.Nodes.Count == 0) return;

        // Find bounds of all nodes
        Vector2 min = currentDialogue.Nodes[0].EditorPosition;
        Vector2 max = currentDialogue.Nodes[0].EditorPosition + currentDialogue.Nodes[0].NodeSize;

        foreach (var node in currentDialogue.Nodes)
        {
            min = Vector2.Min(min, node.EditorPosition);
            max = Vector2.Max(max, node.EditorPosition + node.NodeSize);
        }

        // Center the scroll
        Vector2 center = (min + max) / 2f;
        scrollPosition = center - new Vector2(position.width / 2, position.height / 2);

        Repaint();
    }

    /// <summary>
    /// Creates a new dialogue asset
    /// </summary>
    private void CreateNewDialogue()
    {
        Dialogue newDialogue = CreateInstance<Dialogue>();

        string path = EditorUtility.SaveFilePanelInProject(
            "Save Dialogue",
            "NewDialogue",
            "asset",
            "Please enter a file name to save the dialogue to");

        if (string.IsNullOrEmpty(path)) return;

        AssetDatabase.CreateAsset(newDialogue, path);
        AssetDatabase.SaveAssets();

        currentDialogue = newDialogue;
        AddNewNode();
    }

    private void OnSelectionChange()
    {
        if (Selection.activeObject is Dialogue)
        {
            currentDialogue = Selection.activeObject as Dialogue;
            Repaint();
        }
    }
}
#endif

